g++ -fopenmp -pthread scatter_sieve.cpp -o sieve
./sieve
