g++ -pthread question1-c.cpp -o q1-c
./q1-c
rm ./q1-c
