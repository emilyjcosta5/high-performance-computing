g++ -pthread question1.cpp -o q1
./q1
rm ./q1
