g++ -pthread question1-a.cpp -o q1-a
./q1-a
rm ./q1-a
