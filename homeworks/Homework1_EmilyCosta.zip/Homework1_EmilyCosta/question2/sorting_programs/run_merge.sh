g++ -pthread merge_sort.cpp -o merge_sort
./merge_sort
